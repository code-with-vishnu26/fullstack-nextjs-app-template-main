export default useKeyPress;
declare function useKeyPress({ keyCode, handleDown, handleUp, spyElement }: {
    keyCode: any;
    handleDown: any;
    handleUp: any;
    spyElement: any;
}, deps: any): boolean;
