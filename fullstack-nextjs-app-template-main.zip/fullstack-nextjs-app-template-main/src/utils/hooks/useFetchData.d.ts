export default useFetchData;
declare function useFetchData(actions: any): unknown[];
