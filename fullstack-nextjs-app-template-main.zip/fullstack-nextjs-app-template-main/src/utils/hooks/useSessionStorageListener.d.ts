export default useSessionStorageListener;
declare function useSessionStorageListener(key: any): string;
