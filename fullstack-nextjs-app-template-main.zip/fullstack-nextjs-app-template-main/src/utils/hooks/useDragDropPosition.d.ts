export function useDragDropPosition(settings: any): {
    ref: import("react").RefObject<any>;
    setup: (node: any) => void;
};
