export default useLocalStorage;
declare function useLocalStorage(key: any, defaultValue: any): any[];
