export default useThrottle;
declare function useThrottle(fn: any, delay: any, dependence: any): (...args: any[]) => void;
