export default useDebounce;
declare function useDebounce(fn: any, delay: any, dependence: any): (...args: any[]) => void;
