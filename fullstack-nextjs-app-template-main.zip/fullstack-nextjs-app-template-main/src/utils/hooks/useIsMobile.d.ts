export default useIsMobile;
declare function useIsMobile(breakpoint?: number): boolean;
