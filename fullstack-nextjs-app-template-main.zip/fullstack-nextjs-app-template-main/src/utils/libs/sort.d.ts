/**
 * Quick Sort
 *
 * @param {Array} arr input array
 * @return {String} new array
 */
export function quickSort(arr: any[]): string;
