export function loadTextures(arr: any, perLoadedCallback: any): Promise<any[]>;
